<div class="list-group">
<a class="list-group-item active">Menu</a>
<a href="<?=base_url();?>" class="list-group-item"><span class="glyphicon glyphicon-shopping-cart"></span> Transaksi</a>
<a href="<?=base_url('link/geturi/tambah_daftar');?>" class="list-group-item"><span class="glyphicon glyphicon-plus"></span> Tambah Daftar Barang</a>
<a href="<?=base_url('pengaturan/daftar_barang');?>" class="list-group-item"><span class="glyphicon glyphicon-list-alt"></span> Daftar Barang</a>

</div>
